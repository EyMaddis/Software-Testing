package fi.utu.library;

import static org.junit.Assert.*;

import org.junit.Test;

public class LibraryTest {

	@Test
	public void testSortByBasePrice() {
		fail("Not yet implemented");
	}

}
